<?php

require __DIR__ . '/../api/vendor/autoload.php';

use Medoo\Medoo;

class Customer {
	private $database;
	private $telegram_id;
	private $user;

    public function __construct($telegram_id) {
        $this->database = new Medoo([
            'type' => 'mysql',
            'host' => 'localhost', // DATABASE HOST
            'database' => '', // DATABASE NAME
            'username' => '', // DATABASE USERNAME
            'password' => '' // DATABASE PASSWORD
        ]);
		if(!$this->database->has('customers', ['telegram_id' => $telegram_id])){
			$this->database->insert('customers', [
				'coins' => 1000,
				'telegram_id' => $telegram_id
			]);
		}
        $this->user = $this->database->get('customers', '*', ['telegram_id' => $telegram_id]);
    }

	public function getTelegramID() {
		return $this->user['telegram_id'];
	}

	public function getAccessKey() {
		return $this->user['access_key'];
	}

	public function revokeAccessKey() {
		$newAccessKey = strtoupper(substr(str_shuffle(MD5(microtime())), 0, 10));
        $this->database->update('customers', ['access_key' => $newAccessKey], ['telegram_id' => $this->getTelegramID()]);
        return $newAccessKey;
	}

	public function getCredits() {
		return $this->user['coins'];
	}

	public function setCredits($balance, $prefix = "") {
		$this->database->update('customers', ["coins{$prefix}" => $balance], ['telegram_id' => $this->getTelegramID()]);
	}

	public function getIsUnlimited() {
		return $this->user['is_unlimited'];
	}

	public function setIsUnlimited($value) {
		$this->database->update('customers', ["is_unlimited" => $value], ['telegram_id' => $this->getTelegramID()]);
	}

	public function getIsBlocked() {
		return $this->user['is_blocked'];
	}

	public function setIsBlocked($value) {
		$this->database->update('customers', ["is_blocked" => $value], ['telegram_id' => $this->getTelegramID()]);
	}
}
