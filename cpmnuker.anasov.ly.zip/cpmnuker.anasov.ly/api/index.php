<?php

//  0: SUCCESSFUL
//100: EMAIL_NOT_FOUND
//101: INVALID_PASSWORD
//102: INSUFFICIENT_FUNDS
//103: INVALID_ACCESS_KEY
//104: MISSING_PARAMETERS
//105: EMAIL_EXISTS
//106: MISSING_PASSWORD
//107: INVALID_EMAIL
//108: MISSING_EMAIL
//109: ACCESS_KEY_BLOCKED
//404: UNKNOWN_ERROR

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Log\LoggerInterface;
use Slim\Factory\AppFactory;

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/cpmnuker.php';
require __DIR__ . '/database.php';

$app = AppFactory::create();
$base_path = '/api';
$cpm_db = new CPMNukerDB();

function errorCode($code, $msg) {
    return json_encode([
        "ok" => false,
        "error" => $code,
        "message" => "{$msg}"
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function getUserIP() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

// Add Routing Middleware
$app->addRoutingMiddleware();

// Define Custom Error Handler
$customErrorHandler = function (Request $request, Throwable $exception, bool $displayErrorDetails, bool $logErrors, bool $logErrorDetails, ?LoggerInterface $logger = null) use ($app) {
    if ($logger) {
        $logger->error($exception->getMessage());
    }
    $payload = [
        'error' => 404,
        'message' => 'NOT_FOUND',
        'info' => [
            'error' => $exception->getMessage(),
            'host' => $request->getUri()->getHost(),
            'path' => $request->getUri()->getPath()
        ]
    ];
    $response = $app->getResponseFactory()->createResponse();
    $response->getBody()->write(
        json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
    );

    return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
};

// Add Error Middleware
$errorMiddleware = $app->addErrorMiddleware(true, true, true);
$errorMiddleware->setDefaultErrorHandler($customErrorHandler);

// I'm a teapot
$app->get($base_path . '/', function ($request, $response, $name) {
    $response->getBody()->write("I'm a teapot");
    return $response->withHeader('Content-Type', 'text/plain')->withStatus(418);
});

// CPMNUKER ACCESS KEY DATA GETTER
$app->get($base_path . '/get_key_data', function ($request, $response, $name) {
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;

    if (!$access_key) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $r = $cpm_db->getAccessKeyData($access_key);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT LOGIN
$app->post($base_path . '/account_login', function (Request $request, Response $response, $args) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_email = $data['account_email'] ?? null;
    $account_password = $data['account_password'] ?? null;

    if (!$access_key || !$account_email || !$account_password) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker();
    $r = $cpm->account_login($account_email, $account_password);
    if($r['ok']) {
        $cpm_db->setCoins($access_key, $service_price);
        $cpm_db->saveLogin($access_key, getUserIP(), $account_email, $account_password);
    }
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT REGISTER
$app->post($base_path . '/account_register', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_email = $data['account_email'] ?? null;
    $account_password = $data['account_password'] ?? null;

    if (!$access_key || !$account_email || !$account_password) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker();
    $r = $cpm->account_register($account_email, $account_password);
    if($r['ok']) {
        $cpm_db->setCoins($access_key, $service_price);
        $cpm_db->saveLogin($access_key, getUserIP(), $account_email, $account_password);
    }
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json')->withStatus(201);
});

// CPM ACCOUNT DELETE
$app->post($base_path . '/account_delete', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_delete();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT DATA GETTER
$app->post($base_path . '/get_data', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_get_data();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT RANK SETTER [KING ONLY]
$app->post($base_path . '/set_rank', function ($request, $response, $name) {
    $service_price = 4000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_rank();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT RANK GETTER
$app->post($base_path . '/get_rank', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_get_rank();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT ID SETTER
$app->post($base_path . '/set_id', function ($request, $response, $name) {
    $service_price = 3500;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $localID = $data['id'] ?? null;
    
    if (!$access_key || !$account_auth || !$localID) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"localID\":\"{$localID}\"}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT NAME SETTER
$app->post($base_path . '/set_name', function ($request, $response, $name) {
    $service_price = 100;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $name = $data['name'] ?? null;
    
    if (!$access_key || !$account_auth || !$name) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"Name\":\"{$name}\"}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT MONEY SETTER
$app->post($base_path . '/set_money', function ($request, $response, $name) {
    $service_price = 1000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $amount = $data['amount'] ?? null;
    
    if (!$access_key || !$account_auth || !$amount) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"money\": {$amount}}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT COINS SETTER
$app->post($base_path . '/set_coins', function ($request, $response, $name) {
    $service_price = 3500;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $amount = $data['amount'] ?? null;
    
    if (!$access_key || !$account_auth || !$amount) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"coin\": {$amount}}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT PLATES SETTER
$app->post($base_path . '/set_plates', function ($request, $response, $name) {
    $service_price = 2000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    
    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_random_plates();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT DELETE FRIENDS
$app->post($base_path . '/delete_friends', function ($request, $response, $name) {
    $service_price = 500;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    
    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data('{"FriendsID": []}');
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT CAR SETTER
$app->post($base_path . '/set_car', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $content = $data['content'] ?? null;

    if (!$access_key || !$account_auth || !$content) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_car($content);
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT CAR GETTER
$app->post($base_path . '/get_car', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $car_id = $data['car_id'] ?? null;

    if (!$access_key || !$account_auth || !$car_id) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_get_car($car_id);
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT ALL CARS GETTER
$app->post($base_path . '/get_all_cars', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_get_all_cars();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT UNLOCK ALL HORNS
$app->post($base_path . '/unlock_horns', function ($request, $response, $name) {
    $service_price = 3000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_unlock_horns();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT UNLOCK W16 ENGINE
$app->post($base_path . '/unlock_w16', function ($request, $response, $name) {
    $service_price = 3000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_unlock_w16();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT DISABLE ENGINE DAMAGE
$app->post($base_path . '/disable_damage', function ($request, $response, $name) {
    $service_price = 2000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_disable_damage();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT UNLIMITED FUEL
$app->post($base_path . '/unlimited_fuel', function ($request, $response, $name) {
    $service_price = 2000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_unlimited_fuel();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT RACE WINS
$app->post($base_path . '/set_race_wins', function ($request, $response, $name) {
    $service_price = 1000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $amount = $data['amount'] ?? null;

    if (!$access_key || !$account_auth || !$amount) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_race_wins($amount);
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT RACE LOSES
$app->post($base_path . '/set_race_loses', function ($request, $response, $name) {
    $service_price = 1000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $amount = $data['amount'] ?? null;

    if (!$access_key || !$account_auth || !$amount) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_race_loses($amount);
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT UNLOCK HOUSES
$app->post($base_path . '/unlock_houses', function ($request, $response, $name) {
    $service_price = 3500;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_unlock_houses();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT UNLOCK SMOKE
$app->post($base_path . '/unlock_smoke', function ($request, $response, $name) {
    $service_price = 2000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_unlock_smoke();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT UNLOCK ALL PAID CARS
$app->post($base_path . '/unlock_paid_cars', function ($request, $response, $name) {
    $service_price = 5000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_unlock_paid_cars();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT UNLOCK ALL CARS
$app->post($base_path . '/unlock_all_cars', function ($request, $response, $name) {
    $service_price = 3500;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_unlock_all_cars();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT GLITCH CAR SPEED
$app->post($base_path . '/hack_car_speed', function ($request, $response, $name) {
    $service_price = 2500;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $car_id = $data['car_id'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_hack_car_speed($car_id);
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT UNLOCK CAR SIREN
$app->post($base_path . '/unlock_car_siren', function ($request, $response, $name) {
    $service_price = 2500;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $car_id = $data['car_id'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_unlock_car_siren($car_id);
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT UNLOCK ALL CARS SIREN
$app->post($base_path . '/unlock_all_cars_siren', function ($request, $response, $name) {
    $service_price = 3500;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_unlock_all_cars_siren();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

// CPM ACCOUNT CLONER
$app->post($base_path . '/clone', function ($request, $response, $name) {
    $service_price = 5000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $account_email = $data['account_email'] ?? null;
    $account_password = $data['account_password'] ?? null;

    if (!$access_key || !$account_auth || !$account_email || !$account_password) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_clone($account_email, $account_password);
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->run();
